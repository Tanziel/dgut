package com.example.dailycalories1

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Paint
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import android.widget.TimePicker
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.jjoe64.graphview.DefaultLabelFormatter
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : AppCompatActivity() {
    companion object {
        const val ADD_ACTIVITY_REQUEST_CODE = 1001
    }
    private lateinit var btnAdd: Button // 声明按钮变量
    private lateinit var beginTextView: TextView
    private lateinit var endTextView: TextView
    private lateinit var beginCalendar: Calendar
    private lateinit var endCalendar: Calendar
    private lateinit var queryButton: Button
    private lateinit var graphView: GraphView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // 通过 findViewById 获取按钮的引用
        btnAdd = findViewById(R.id.btnAdd)
        beginTextView = findViewById(R.id.begin)
        endTextView = findViewById(R.id.end)
        queryButton = findViewById(R.id.query)
        graphView = findViewById(R.id.graph)

        // 初始化 Calendar 对象
        beginCalendar = Calendar.getInstance()
        endCalendar = Calendar.getInstance()

        // 为 "begin" 文本视图设置点击事件监听器
        beginTextView.setOnClickListener {
            showDatePickerDialog(beginCalendar)
        }
        endTextView.setOnClickListener {
            showDatePickerDialog(endCalendar) // 传入 endCalendar
        }
        // 为按钮添加点击事件
        btnAdd.setOnClickListener {
            // 创建一个 Intent 对象，指定从 MainActivity 跳转到 add
            val intent = Intent(this, add::class.java)
            // 启动 EditActivity
            startActivity(intent)
        } // 设置点击事件监听器
        queryButton.setOnClickListener {
            // 获取起始日期和结束日期
            val startDate = beginTextView.text.toString()
            val endDate = endTextView.text.toString()

            // 从数据库中获取数据，这里假设函数名为getDataFromDatabase()
            val data = getDataFromDatabase(startDate, endDate)

            // 绘制折线图
            drawGraph(data)
        }

    }
    private fun showDatePickerDialog(calendar: Calendar) {
        val datePickerDialog = DatePickerDialog(
            this,
            { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
                calendar.set(year, month, dayOfMonth)
                updateDateTimeTextViews()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    private fun updateDateTimeTextViews() {
        val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
        beginTextView.text = dateFormat.format(beginCalendar.time)
        endTextView.text = dateFormat.format(endCalendar.time)
    }
    private fun getDataFromDatabase(startDate: String, endDate: String): List<Pair<Date, Int>> {
        // 这里应该从数据库中根据起始日期和结束日期获取数据，
        // 返回的数据应该是一个包含日期和卡路里数的列表
        // 这里用一个假数据代替
        val data = mutableListOf<Pair<Date, Int>>()
        val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
        val random = Random()
        val calendar = Calendar.getInstance()
        calendar.time = dateFormat.parse(startDate) ?: Date()
        while (calendar.time <= dateFormat.parse(endDate) ?: Date()) {
            // 假数据：如果日期在数据中，则随机生成一个卡路里数，否则卡路里数为 0
            val calorie = if (random.nextBoolean()) random.nextInt(1000) else 0
            data.add(calendar.time to calorie)
            calendar.add(Calendar.DAY_OF_MONTH, 1) // 递增日期
        }
        return data
    }



    private fun drawGraph(data: List<Pair<Date, Int>>) {
        val series = LineGraphSeries<DataPoint>(
            data.filter { it.second != 0 }.map { (date, calorie) ->
                DataPoint(date.time.toDouble(), calorie.toDouble())
            }.toTypedArray()
        )

        graphView.removeAllSeries()
        graphView.addSeries(series)

        graphView.gridLabelRenderer.labelFormatter = object : DefaultLabelFormatter() {
            override fun formatLabel(value: Double, isValueX: Boolean): String {
                if (isValueX) {
                    val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                    val date = Date(value.toLong())
                    val formattedDate = dateFormat.format(date)
                    return formattedDate.replace("/", "\n") // 竖直显示日期
                } else {
                    return super.formatLabel(value, isValueX)
                }
            }
        }



        graphView.gridLabelRenderer.verticalAxisTitle = "Calorie"

        val maxCalorie = data.maxByOrNull { it.second }?.second ?: 0
        graphView.viewport.setMaxY(maxCalorie.toDouble())

        val start = data.first().first
        val end = data.last().first
        graphView.viewport.setMinX(start.time.toDouble())
        graphView.viewport.setMaxX(end.time.toDouble())
        graphView.viewport.isXAxisBoundsManual = true
        graphView.viewport.isScrollable = true
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ADD_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
            // 更新图表
            val startDate = beginTextView.text.toString()
            val endDate = endTextView.text.toString()
            val newData = getDataFromDatabase(startDate, endDate)
            drawGraph(newData)
        }
    }
}
