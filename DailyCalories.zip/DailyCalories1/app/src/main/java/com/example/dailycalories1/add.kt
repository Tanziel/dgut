package com.example.dailycalories1
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class add : AppCompatActivity() {
    private lateinit var backButton: Button
    private lateinit var submitButton: Button
    private lateinit var editText: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MyAdapter
    private val itemList = mutableListOf<Item>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add)

        // 获取 Back 按钮、Submit 按钮、EditText 和 RecyclerView 的引用
        backButton = findViewById(R.id.back)
        submitButton = findViewById(R.id.submitBtn)
        editText = findViewById(R.id.editText)
        recyclerView = findViewById(R.id.rView)

        // 设置 RecyclerView 的布局管理器和适配器
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MyAdapter(itemList)
        recyclerView.adapter = adapter

        // 为 Back 按钮添加点击事件
        backButton.setOnClickListener {
            // 创建一个 Intent 对象，指定从 AddActivity 返回到 MainActivity
            val intent = Intent(this, MainActivity::class.java)
            // 启动 MainActivity
            startActivity(intent)
        }

        // 为 Submit 按钮添加点击事件
        submitButton.setOnClickListener {
            // 获取 EditText 中的数字
            val calories = editText.text.toString()

            // 如果 EditText 为空，则显示提示消息并返回
            if (calories.isBlank()) {
                Toast.makeText(this, "请输入Calories", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 显示日期选择对话框
            showDatePickerDialog(calories)



            // 清空 EditText
            editText.text.clear()
        }
        adapter.onItemLongClickListener = object : MyAdapter.OnItemLongClickListener {
            override fun onItemLongClick(position: Int) {
                val builder = AlertDialog.Builder(this@add)
                builder.setTitle("Confirm Delete")
                builder.setMessage("Are you sure you want to delete this item?")
                builder.setPositiveButton("Yes") { _, _ ->
                    // 删除数据项
                    itemList.removeAt(position)
                    adapter.notifyItemRemoved(position)
                    Toast.makeText(this@add, "Item deleted", Toast.LENGTH_SHORT).show()
                }
                builder.setNegativeButton("Cancel") { _, _ ->
                    // Do nothing
                }
                builder.show()
            }
        }
    }
    private fun showDatePickerDialog(calories: String) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                // 获取选择的日期
                val selectedDate = Calendar.getInstance()
                selectedDate.set(selectedYear, selectedMonth, selectedDayOfMonth)

                // 将数字和日期添加到 RecyclerView 中
                val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                val currentDate = dateFormat.format(selectedDate.time)
                itemList.add(Item(calories, currentDate))
                adapter.notifyDataSetChanged()

                // 将数据返回给 MainActivity
                val intent = Intent()
                intent.putExtra("calories", calories)
                intent.putExtra("date", currentDate)
                setResult(RESULT_OK, intent)
                // 清空 EditText
                editText.text.clear()
            },
            year, month, dayOfMonth
        )
        datePickerDialog.show()
    }

}
// Item 类用于表示 RecyclerView 中的每个条目
data class Item(val calories: String, val date: String)

class MyAdapter(private val itemList: MutableList<Item>) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {

    interface OnItemLongClickListener {
        fun onItemLongClick(position: Int)
    }

    var onItemLongClickListener: OnItemLongClickListener? = null

    // ViewHolder 用于缓存 RecyclerView 中的视图
    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view), View.OnLongClickListener {
        val caloriesTextView: TextView = view.findViewById(R.id.caloriesTextView)
        val dateTextView: TextView = view.findViewById(R.id.dateTextView)

        init {
            view.setOnLongClickListener(this)
        }

        override fun onLongClick(v: View): Boolean {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                onItemLongClickListener?.onItemLongClick(position)
            }
            return true
        }
    }

    // 创建 ViewHolder 并返回
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_list, parent, false)
        return ViewHolder(view)
    }

    // 将数据绑定到 ViewHolder 上
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = itemList[position]
        holder.caloriesTextView.text = item.calories
        holder.dateTextView.text = item.date
    }

    // 返回条目数量
    override fun getItemCount(): Int {
        return itemList.size
    }
}
