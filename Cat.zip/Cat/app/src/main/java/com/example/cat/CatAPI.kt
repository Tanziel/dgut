package com.example.cat

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface CatApiService {
    @GET("https://api.thecatapi.com/v1/images/search?limit=10&api_key=live_q4hEnzc3Kh6b1Isvx1NWOd2FtW5MmNHvP58ryV3raXPeZHSWL1YsGeUYxoaB8yPR")

    fun getRandomCats(
        @Query("format") format: String = "json",
        @Query("size") size: String = "med",
        @Query("results_per_page") resultsPerPage: Int = 9
    ): Call<List<CatImage>>

}