package com.example.cat


import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory



data class CatImage(
    val id: String,
    val url: String,
    val width: Int,
    val height: Int
)
class MainActivity : AppCompatActivity() {

    private lateinit var imageViewList: MutableList<ImageView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageViewList = mutableListOf(
            findViewById(R.id.imageView),
            findViewById(R.id.imageView2),
            findViewById(R.id.imageView3),
            findViewById(R.id.imageView4),
            findViewById(R.id.imageView5),
            findViewById(R.id.imageView6),
            findViewById(R.id.imageView7),
            findViewById(R.id.imageView8),
            findViewById(R.id.imageView9)
        )

        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {
            fetchCatImages()
        }
    }

    private fun fetchCatImages() {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.thecatapi.com/v1/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(CatApiService::class.java)
        service.getRandomCats().enqueue(object : Callback<List<CatImage>> {
            override fun onResponse(
                call: Call<List<CatImage>>,
                response: Response<List<CatImage>>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    val catImageUrls = response.body()!!.map { it.url }
                    displayCatImages(catImageUrls)
                } else {
                    println("Error: ${response.code()} ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<CatImage>>, t: Throwable) {
                println("Request failed: ${t.message}")
            }
        })
    }

    private fun displayCatImages(urls: List<String>) {
        urls.forEachIndexed { index, url ->
            if (index < imageViewList.size) {
                Glide.with(this)
                    .load(url)
                    .into(imageViewList[index])
            }
        }
    }
}




